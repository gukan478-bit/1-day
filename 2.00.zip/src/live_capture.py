"""Continuous local tshark capture for rolling network inference."""

from __future__ import annotations

import os
import select
import subprocess
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional


FIELDS = [
    "frame.time_epoch", "ip.src", "ip.dst", "tcp.srcport", "tcp.dstport",
    "ip.proto", "tcp.flags", "ip.ttl", "tcp.window_size", "ip.frag_offset",
    "frame.len",
]


def first_interface() -> str:
    """Return the first non-loopback interface reported by tshark."""
    try:
        completed = subprocess.run(
            ["tshark", "-D"], check=True, capture_output=True, text=True, timeout=10
        )
    except FileNotFoundError as exc:
        raise RuntimeError("tshark is required for live mode. Install it with: sudo apt install tshark") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(exc.stderr.strip() or "Unable to enumerate capture interfaces") from exc
    interfaces = []
    for line in completed.stdout.splitlines():
        if ". " not in line:
            continue
        name, _, description = line.partition(". ")
        interface = description.split(" ", 1)[0]
        lowered = f"{interface} {description}".lower()
        if "loopback" not in lowered and interface not in {"lo", "any"}:
            interfaces.append(interface)
    if interfaces:
        return interfaces[0]
    raise RuntimeError("No non-loopback capture interface was found.")


def _number(value: str, default: float = 0.0) -> float:
    try:
        return float(value, )
    except (TypeError, ValueError):
        return default


class LiveCapture:
    """Read packet records continuously and keep only a bounded history."""

    def __init__(self, interface: Optional[str] = None, max_records: int = 50000):
        self.interface = interface or first_interface()
        self.records: Deque[Dict[str, Any]] = deque(maxlen=max_records)
        self._previous_by_flow: Dict[tuple, float] = {}
        self.process: Optional[subprocess.Popen] = None

    def start(self) -> None:
        command = [
            "tshark", "-l", "-n", "-i", self.interface, "-Y", "ip",
            "-T", "fields", "-E", "separator=\t", "-E", "quote=n",
        ]
        for field in FIELDS:
            command.extend(["-e", field])
        try:
            self.process = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, bufsize=1,
            )
        except FileNotFoundError as exc:
            raise RuntimeError("tshark is required for live mode. Install it with: sudo apt install tshark") from exc

    def _parse_line(self, line: str) -> Optional[Dict[str, Any]]:
        values = line.rstrip("\r\n").split("\t")
        if len(values) < len(FIELDS):
            return None
        timestamp = _number(values[0])
        src_ip, dst_ip = values[1], values[2]
        src_port = int(_number(values[3]))
        dst_port = int(_number(values[4]))
        protocol_number = values[5]
        protocol = {"6": "TCP", "17": "UDP", "1": "ICMP"}.get(protocol_number, "OTHER")
        try:
            flag_bits = int(values[6], 0)
        except ValueError:
            flag_bits = int(_number(values[6], 0.0))
        flags = "".join(
            flag for bit, flag in (
                (0x01, "F"), (0x02, "S"), (0x04, "R"),
                (0x08, "P"), (0x10, "A"), (0x20, "U"),
            ) if flag_bits & bit
        )
        flow = (src_ip, dst_ip, src_port, dst_port, protocol)
        previous = self._previous_by_flow.get(flow)
        iat = max(0.0, timestamp - previous) if previous is not None else 0.0
        self._previous_by_flow[flow] = timestamp
        expiry = timestamp - 300.0
        for old_flow, old_timestamp in list(self._previous_by_flow.items()):
            if old_timestamp < expiry:
                del self._previous_by_flow[old_flow]
        return {
            "timestamp": timestamp,
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "src_port": src_port,
            "dst_port": dst_port,
            "protocol": protocol,
            "tcp_flags": flags,
            "ttl": _number(values[7]),
            "tcp_window": _number(values[8]),
            "ip_frag": 1 if _number(values[9]) > 0 else 0,
            "payload_size": max(0.0, _number(values[10]) - 40.0),
            "packet_length": _number(values[10]),
            "iat": iat,
            "is_retransmission": 0,
        }

    def read_for(self, seconds: float) -> int:
        """Read available packets for a bounded refresh interval."""
        if self.process is None or self.process.stdout is None:
            raise RuntimeError("Live capture is not running.")
        added = 0
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            remaining = max(0.0, deadline - time.monotonic())
            ready, _, _ = select.select([self.process.stdout], [], [], remaining)
            if not ready:
                break
            line = self.process.stdout.readline()
            if not line:
                error = self.process.stderr.read().strip() if self.process.stderr else ""
                raise RuntimeError(error or "The live capture process stopped.")
            record = self._parse_line(line)
            if record:
                self.records.append(record)
                added += 1
        return added

    def snapshot(self) -> List[Dict[str, Any]]:
        return list(self.records)

    def close(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
        self.process = None
