"""
forecast.py
===========
Live/offline inference entry point. Takes a PCAP or flow CSV, runs it
through the full pipeline, and produces the attack-probability timeline,
predicted future attack stage, contributing features, and suspicious
flows — either as a returned dict (for main.py's dashboard rendering) or
printed directly when run standalone.

Usage:
    python3 forecast.py --pcap captures/capture.pcap --steps 5
    python3 forecast.py --csv traffic.csv --run-name default

    # Multi-input / batch mode (many files and/or directories in one call):
    python3 forecast.py --input captures/ more_captures/extra.pcap --run-name default
    python3 forecast.py --input a.csv b.csv --combine --run-name default
"""

from __future__ import annotations
import argparse
import logging
import os
import pickle
import sys
from typing import Dict, Any, List, Optional, Sequence, Tuple

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    PATHS, ATTACK_STAGES, DEFAULT_ALERT, SequenceConfig, ModelConfig,
    FEATURE_VECTOR_ORDER,
)
from feature_extraction import extract, extract_many, collect_input_paths, PacketParseError
from windowing import build_state_sequence, report_feature_availability, WindowConfig
from preprocessing import StandardScaler, build_sequences, load_json
from world_model import NetworkWorldModel
from explain import explain_alert, suspicious_flows

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("forecast")


class ForecasterNotTrainedError(Exception):
    pass


def load_run_artifacts(run_name: str):
    run_dir = os.path.join(PATHS["models"], run_name)
    cfg_path = os.path.join(run_dir, "run_config.json")
    if not os.path.exists(cfg_path):
        raise ForecasterNotTrainedError(
            f"No trained model found for run '{run_name}' at {run_dir}. "
            f"Run train.py first, e.g.: python3 train.py --dataset cic-ids2018 "
            f"--data-dir data/raw/cic-ids2018 --run-name {run_name}"
        )
    run_cfg = load_json(cfg_path)
    seq_cfg = SequenceConfig(sequence_length=run_cfg["sequence_length"],
                              forecast_horizon=run_cfg["forecast_horizon"])
    model_cfg = ModelConfig()
    model = NetworkWorldModel(feature_dim=run_cfg["feature_dim"], model_cfg=model_cfg, seq_cfg=seq_cfg)
    model.load_state_dict(torch.load(os.path.join(run_dir, "world_model.pt"), map_location="cpu"))
    model.eval()

    scaler = StandardScaler.load(os.path.join(PATHS["scalers"], f"{run_name}_scaler.pkl"))
    window_cfg = WindowConfig(window_seconds=run_cfg["window_seconds"],
                               stride_seconds=run_cfg["window_seconds"])
    classifier = None
    classifier_path = os.path.join(run_dir, "attack_classifier.pkl")
    if os.path.exists(classifier_path):
        with open(classifier_path, "rb") as f:
            classifier = pickle.load(f)
    return model, scaler, seq_cfg, window_cfg, run_cfg, classifier


def run_forecast(input_path: str, run_name: str = "default", steps: int = None,
                 artifacts: Optional[Tuple] = None) -> Dict[str, Any]:
    """Run inference from a capture/CSV path.

    ``artifacts``, when provided, must be the tuple returned by
    ``load_run_artifacts()``. Passing it in lets a caller processing many
    inputs against the same run (e.g. run_forecast_many, or a server loop)
    load the model/scaler from disk exactly once instead of once per file.
    """
    records = extract(input_path)
    return run_forecast_records(records, input_path, run_name=run_name, steps=steps,
                                artifacts=artifacts)


def run_forecast_records(records: List[Dict[str, Any]], input_name: str,
                         run_name: str = "default", steps: int = None,
                         artifacts: Optional[Tuple] = None) -> Dict[str, Any]:
    """Run inference from already parsed records, used by live streaming mode."""
    if artifacts is None:
        artifacts = load_run_artifacts(run_name)
    model, scaler, seq_cfg, window_cfg, run_cfg, attack_classifier = artifacts
    steps = steps or seq_cfg.forecast_horizon

    if not records:
        raise PacketParseError(f"No records could be extracted from {input_name}")

    availability = report_feature_availability(records)
    state_matrix, raw_windows, start_times = build_state_sequence(records, window_cfg)

    if state_matrix.shape[0] < seq_cfg.sequence_length:
        raise ValueError(
            f"Input only produced {state_matrix.shape[0]} time windows but the "
            f"model needs at least {seq_cfg.sequence_length} (sequence_length) "
            f"to make a prediction. Capture more traffic or reduce --window size."
        )

    scaled_matrix = scaler.transform(state_matrix)

    # use the MOST RECENT sequence_length windows as "current" context
    x_current = scaled_matrix[-seq_cfg.sequence_length:]
    x_tensor = torch.tensor(x_current, dtype=torch.float32).unsqueeze(0)

    with torch.no_grad():
        out = model(x_tensor)
        current_prob = torch.sigmoid(out["threat_logits"][:, 0]).item()
        current_stage_idx = int(out["stage_logits"].argmax(dim=1).item())
        stage_probs = torch.softmax(out["stage_logits"], dim=1).squeeze(0).numpy()
        confidence = float(stage_probs[current_stage_idx])

    # K-step autoregressive rollout for the forecast timeline
    pred_states, threat_probs, final_stage_logits = model.autoregressive_rollout(x_tensor, steps=steps)
    threat_timeline = threat_probs.squeeze(0).numpy().tolist()
    final_stage_idx = int(final_stage_logits.argmax(dim=1).item())

    # progression: current -> intermediate inferred stages (nearest-class
    # at each rollout step) -> final predicted stage. We derive
    # intermediate stages by re-running the stage head on each rolled-out
    # state's own encode() pass for a step-by-step trajectory.
    progression = [ATTACK_STAGES[current_stage_idx]]
    with torch.no_grad():
        rolling_seq = x_tensor.clone()
        for step in range(steps):
            step_out = model(rolling_seq)
            step_stage_idx = int(step_out["stage_logits"].argmax(dim=1).item())
            progression.append(ATTACK_STAGES[step_stage_idx])
            next_state = step_out["next_state"]
            rolling_seq = torch.cat([rolling_seq[:, 1:, :], next_state.unsqueeze(1)], dim=1)
    # collapse consecutive duplicate stages for a readable progression string
    collapsed = [progression[0]]
    for s in progression[1:]:
        if s != collapsed[-1]:
            collapsed.append(s)

    # explainability: background = a sample of earlier windows for SHAP,
    # falls back to occlusion automatically if shap isn't installed / too
    # few background samples exist.
    background = None
    if scaled_matrix.shape[0] > seq_cfg.sequence_length + 10:
        bg_candidates = []
        for _ in range(min(20, scaled_matrix.shape[0] - seq_cfg.sequence_length)):
            i = np.random.randint(0, scaled_matrix.shape[0] - seq_cfg.sequence_length)
            bg_candidates.append(scaled_matrix[i:i + seq_cfg.sequence_length].flatten())
        background = np.array(bg_candidates)

    top_features = explain_alert(model, x_current, background=background, top_k=5,
                                  use_shap=(background is not None))
    latest_state = state_matrix[-1]
    feature_index = {name: i for i, name in enumerate(FEATURE_VECTOR_ORDER)}
    for feature in top_features:
        index = feature_index[feature["feature"]]
        feature["current_value"] = round(float(latest_state[index]), 4)

    current_window_records = raw_windows[-1] if raw_windows else []
    flows = suspicious_flows(current_window_records, top_k=5)

    severity = DEFAULT_ALERT.severity(current_prob)
    attack_type = "Unknown"
    attack_type_confidence = 0.0
    if attack_classifier is not None:
        attack_type = str(attack_classifier.predict(state_matrix[-1:].astype(np.float64))[0])
        if hasattr(attack_classifier, "predict_proba"):
            attack_type_confidence = float(np.max(attack_classifier.predict_proba(
                state_matrix[-1:].astype(np.float64)
            )[0]))

    # The predicted-stage head and the threat-probability head are trained
    # jointly but can disagree in an undertrained or low-data model (e.g.
    # HIGH probability with a BENIGN stage label). Word the recommendation
    # around whichever non-benign stage is actually present in the
    # progression, and fall back to a probability-only phrasing rather
    # than asserting a "benign trajectory" is worth investigating.
    non_benign_stages = [s for s in collapsed if s != "BENIGN"]
    trajectory_label = non_benign_stages[-1].replace("_", " ").lower() if non_benign_stages else None

    recommendations = {
        "LOW": "Continue routine monitoring; no immediate action required.",
        "MEDIUM": "Review flagged flows; consider increasing capture granularity.",
        "HIGH": (f"Investigate the predicted {trajectory_label} trajectory."
                 if trajectory_label else
                 "Threat probability is elevated despite no specific non-benign stage "
                 "being predicted — review flagged flows and consider more training data."),
        "CRITICAL": (f"Immediate investigation recommended — trajectory points toward "
                      f"{trajectory_label}. Isolate suspicious hosts if confirmed."
                      if trajectory_label else
                      "Threat probability is critical despite no specific non-benign stage "
                      "being predicted — treat as a high-priority anomaly and investigate "
                      "flagged flows immediately."),
    }

    return {
        "input": input_name,
        "window_seconds": window_cfg.window_seconds,
        "forecast_steps": steps,
        "current_threat_probability": round(current_prob, 4),
        "risk_level": severity,
        "predicted_stage": ATTACK_STAGES[current_stage_idx],
        "predicted_attack_type": attack_type,
        "attack_type_confidence": round(attack_type_confidence, 4),
        "confidence": round(confidence, 4),
        "forecast_timeline": [
            {"offset_seconds": (i + 1) * window_cfg.window_seconds, "probability": round(p, 4)}
            for i, p in enumerate(threat_timeline)
        ],
        "attack_progression": collapsed,
        "top_features": top_features,
        "suspicious_flows": flows,
        "recommendation": recommendations[severity],
        "feature_availability": availability,
        "total_windows_observed": int(state_matrix.shape[0]),
        "current_features": {
            name: round(float(value), 4)
            for name, value in zip(FEATURE_VECTOR_ORDER, latest_state)
        },
    }


_RISK_RANK = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}


def summarize_forecasts(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Roll many per-input results into one aggregate view.

    Surfaces the single highest-risk input first, since that is usually
    what a server triaging many files/sensors at once actually needs to
    act on, alongside a mean threat probability across everything scored.
    """
    if not results:
        return {
            "file_count": 0,
            "ok_count": 0,
            "error_count": 0,
            "highest_threat_probability": 0.0,
            "highest_risk_level": None,
            "highest_risk_input": None,
            "mean_threat_probability": 0.0,
            "files": [],
        }
    worst = max(
        results,
        key=lambda r: (_RISK_RANK.get(r["risk_level"], -1), r["current_threat_probability"]),
    )
    mean_prob = sum(r["current_threat_probability"] for r in results) / len(results)
    return {
        "file_count": len(results),
        "ok_count": len(results),
        "error_count": 0,
        "highest_threat_probability": worst["current_threat_probability"],
        "highest_risk_level": worst["risk_level"],
        "highest_risk_input": worst["input"],
        "mean_threat_probability": round(mean_prob, 4),
        "files": [
            {"input": r["input"], "risk_level": r["risk_level"],
             "current_threat_probability": r["current_threat_probability"]}
            for r in results
        ],
    }


def run_forecast_many(paths: Sequence[str], run_name: str = "default",
                      steps: int = None, combine: bool = False) -> Dict[str, Any]:
    """Forecast many files/directories in one call.

    Default mode scores each file independently (one bad/unparseable file is
    skipped with a logged warning, not fatal to the rest of the batch). The
    model/scaler for ``run_name`` are loaded from disk exactly once and
    reused across every input, which matters when this runs on a server
    against dozens or hundreds of files. ``combine=True`` instead
    concatenates every input's records and produces a single merged
    timeline (useful when the inputs are, e.g., successive captures of the
    same segment).
    """
    resolved = collect_input_paths(paths)
    artifacts = load_run_artifacts(run_name)
    seq_cfg = artifacts[2]
    steps = steps or seq_cfg.forecast_horizon

    if combine:
        records = extract_many(resolved)
        result = run_forecast_records(records, str(resolved), run_name=run_name,
                                      steps=steps, artifacts=artifacts)
        result["inputs"] = resolved
        result["combined"] = True
        return {
            "mode": "combined",
            "results": [result],
            "errors": [],
            "summary": summarize_forecasts([result]),
        }

    results: List[Dict[str, Any]] = []
    errors: List[Dict[str, str]] = []
    for path in resolved:
        try:
            results.append(run_forecast(path, run_name=run_name, steps=steps, artifacts=artifacts))
        except (PacketParseError, ValueError) as e:
            logger.warning("Skipping %s: %s", path, e)
            errors.append({"input": path, "error": str(e)})

    summary = summarize_forecasts(results)
    summary["file_count"] = len(resolved)
    summary["ok_count"] = len(results)
    summary["error_count"] = len(errors)
    return {
        "mode": "batch",
        "results": results,
        "errors": errors,
        "summary": summary,
    }


def add_input_arguments(parser: argparse.ArgumentParser) -> None:
    """Shared --pcap/--csv/--input/--combine flags for main.py and forecast.py."""
    parser.add_argument(
        "--pcap", nargs="+", default=[], metavar="PATH",
        help="One or more .pcap/.pcapng/.cap files or directories.",
    )
    parser.add_argument(
        "--csv", nargs="+", default=[], metavar="PATH",
        help="One or more flow CSV/TSV files or directories.",
    )
    parser.add_argument(
        "--input", nargs="+", default=[], dest="inputs", metavar="PATH",
        help="Mixed capture/CSV files or directories (any extension mix).",
    )
    parser.add_argument(
        "--combine", action="store_true",
        help="Merge all inputs into one timeline instead of scoring each file separately.",
    )


def gather_cli_paths(args: argparse.Namespace) -> List[str]:
    return list(args.pcap or []) + list(args.csv or []) + list(getattr(args, "inputs", None) or [])


def main():
    parser = argparse.ArgumentParser(
        description="Forecast future attack progression from traffic. Accepts one or "
                    "many files/directories via --pcap/--csv/--input."
    )
    add_input_arguments(parser)
    parser.add_argument("--steps", type=int, default=None, help="Forecast horizon override.")
    parser.add_argument("--run-name", default="default", help="Which trained model artifacts to use.")
    args = parser.parse_args()

    paths = gather_cli_paths(args)
    if not paths:
        parser.error("Provide at least one path via --pcap, --csv, and/or --input.")

    import json
    try:
        batch = run_forecast_many(paths, run_name=args.run_name, steps=args.steps,
                                  combine=args.combine)
    except (ForecasterNotTrainedError, PacketParseError, ValueError) as e:
        logger.error(str(e))
        sys.exit(1)

    payload = batch["results"][0] if (
        len(batch["results"]) == 1 and not batch["errors"] and batch["mode"] != "combined"
    ) else batch
    print(json.dumps(payload, indent=2))
    if not batch["results"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
