"""Local Streamlit dashboard for offline and live Kali Linux traffic analysis."""

from __future__ import annotations

import os
import subprocess
import tempfile
from datetime import datetime

import pandas as pd
import streamlit as st

from config import PATHS, WindowConfig
from feature_extraction import extract, PacketParseError
from forecast import ForecasterNotTrainedError, run_forecast
from windowing import build_state_sequence


st.set_page_config(page_title="Network attack monitor", layout="wide")
st.title("Network attack monitor")
st.caption("Local-only UNSW-NB15 model inference and Kali Linux capture telemetry.")


def capture_with_tshark(interface: str, seconds: int) -> str:
    """Capture one bounded PCAP snapshot without invoking a shell."""
    os.makedirs(PATHS["captures"], exist_ok=True)
    path = os.path.join(
        PATHS["captures"], f"live_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pcapng"
    )
    command = ["tshark", "-i", interface, "-a", f"duration:{seconds}", "-w", path]
    try:
        completed = subprocess.run(command, capture_output=True, text=True, timeout=seconds + 15)
    except FileNotFoundError as exc:
        raise RuntimeError("tshark is not installed. On Kali: sudo apt install tshark") from exc
    if completed.returncode != 0:
        message = completed.stderr.strip() or "tshark returned a non-zero exit code"
        raise RuntimeError(message)
    return path


def interfaces():
    try:
        completed = subprocess.run(["tshark", "-D"], capture_output=True, text=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []
    names = []
    for line in completed.stdout.splitlines():
        if ". " in line:
            names.append(line.split(". ", 1)[1].split(" ", 1)[0])
    return names


def prepare_traffic_table(result: dict) -> pd.DataFrame:
    """Prepare full traffic table with sorting and suspicious flags."""
    flows = result.get("all_flows", [])
    suspicious_flows_set = {(f.get("src"), f.get("dst")) for f in result.get("suspicious_flows", [])}
    
    traffic_data = []
    for flow in flows:
        src = flow.get("src", "Unknown")
        dst = flow.get("dst", "Unknown")
        is_suspicious = (src, dst) in suspicious_flows_set
        
        traffic_data.append({
            "Source": src,
            "Destination": dst,
            "Protocol": flow.get("protocol", "Unknown"),
            "Port(s)": flow.get("ports", "N/A"),
            "Attack Stage": flow.get("stage", "N/A"),
            "is_suspicious": is_suspicious,
            "critical_level": flow.get("critical_level", 0),
            "_flow_id": f"{src}_{dst}",
            "_full_details": flow  # Store full flow details for expansion
        })
    
    df = pd.DataFrame(traffic_data)
    
    # Sort: suspicious rows first (by critical level descending), then non-suspicious
    if not df.empty:
        suspicious = df[df["is_suspicious"]].sort_values("critical_level", ascending=False)
        non_suspicious = df[~df["is_suspicious"]]
        df = pd.concat([suspicious, non_suspicious], ignore_index=True)
    
    return df


def render_traffic_table(df: pd.DataFrame):
    """Render traffic table with highlighting, sorting, and expandable rows."""
    if df.empty:
        st.info("No traffic flows detected.")
        return
    
    # Initialize session state for expanded rows
    if "expanded_rows" not in st.session_state:
        st.session_state.expanded_rows = set()
    
    # Display table header
    col1, col2, col3, col4, col5 = st.columns([1.5, 1.5, 1, 1, 1.5])
    with col1:
        st.write("**Source**")
    with col2:
        st.write("**Destination**")
    with col3:
        st.write("**Protocol**")
    with col4:
        st.write("**Port(s)**")
    with col5:
        st.write("**Attack Stage**")
    
    st.divider()
    
    # Display rows
    for idx, row in df.iterrows():
        flow_id = row["_flow_id"]
        is_suspicious = row["is_suspicious"]
        
        # Highlight suspicious rows in yellow
        if is_suspicious:
            st.markdown(f"""
            <div style="background-color: #fffacd; padding: 12px; border-radius: 4px; margin-bottom: 8px;">
                <div style="display: grid; grid-template-columns: 1.5fr 1.5fr 1fr 1fr 1.5fr; gap: 16px;">
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div style="padding: 12px; border-bottom: 1px solid #e0e0e0; margin-bottom: 8px;">
                <div style="display: grid; grid-template-columns: 1.5fr 1.5fr 1fr 1fr 1.5fr; gap: 16px;">
            """, unsafe_allow_html=True)
        
        col1, col2, col3, col4, col5 = st.columns([1.5, 1.5, 1, 1, 1.5])
        
        with col1:
            # Clickable source IP
            if st.button(
                row["Source"],
                key=f"src_{idx}",
                use_container_width=True
            ):
                if flow_id in st.session_state.expanded_rows:
                    st.session_state.expanded_rows.discard(flow_id)
                else:
                    st.session_state.expanded_rows = {flow_id}
                st.rerun()
        
        with col2:
            st.write(row["Destination"])
        
        with col3:
            st.write(row["Protocol"])
        
        with col4:
            st.write(str(row["Port(s)"]))
        
        with col5:
            st.write(row["Attack Stage"])
        
        st.markdown("</div></div>", unsafe_allow_html=True)
        
        # Render detail panel if expanded
        if flow_id in st.session_state.expanded_rows:
            details = row["_full_details"]
            st.markdown("""
            <div style="background-color: #f5f5f5; padding: 16px; border-radius: 4px; margin-left: 16px; margin-bottom: 12px;">
                <strong>Flow Details</strong>
            </div>
            """, unsafe_allow_html=True)
            
            detail_cols = st.columns(2)
            
            with detail_cols[0]:
                st.write(f"**Timestamps:** {details.get('timestamps', 'N/A')}")
                st.write(f"**Packet Count:** {details.get('packet_count', 'N/A')}")
                st.write(f"**Byte Count:** {details.get('byte_count', 'N/A')}")
                st.write(f"**Duration:** {details.get('duration', 'N/A')}")
            
            with detail_cols[1]:
                st.write(f"**Payload Size:** {details.get('payload_size', 'N/A')}")
                st.write(f"**Flags:** {details.get('flags', 'N/A')}")
                st.write(f"**TTL:** {details.get('ttl', 'N/A')}")
                st.write(f"**Window Size:** {details.get('window_size', 'N/A')}")
            
            if details.get("reasoning"):
                st.write(f"**Suspicious Flag Reasoning:** {details.get('reasoning')}")
            
            if details.get("related_stage_data"):
                st.write(f"**Related Stage Data:** {details.get('related_stage_data')}")
            
            st.divider()


def render_result(path: str, result: dict):
    records = extract(path)
    states, _, _ = build_state_sequence(records, WindowConfig(
        window_seconds=result["window_seconds"], stride_seconds=result["window_seconds"]
    ))
    latest = states[-1] if len(states) else [0] * 34
    columns = ["packets", "bytes", "mean_packet_length", "syn_count", "unique_sources",
               "unique_destinations", "tcp_ratio", "udp_ratio", "icmp_ratio"]
    values = [latest[0], latest[1], latest[2], latest[7], latest[14], latest[15],
              latest[27], latest[28], latest[29]]
    
    # Metrics row
    metrics = st.columns(5)
    metrics[0].metric("Attack Potential", f"{result['current_threat_probability'] * 100:.1f}%")
    metrics[1].metric("Risk", result["risk_level"])
    metrics[2].metric("Attack family", result.get("predicted_attack_type", "Unknown"))
    metrics[3].metric("Packets", f"{int(values[0]):,}")
    metrics[4].metric("Bytes", f"{int(values[1]):,}")

    # Additional fields below metrics
    field_cols = st.columns(3)
    with field_cols[0]:
        st.write(f"**Confidence:** {result['confidence'] * 100:.1f}%")
    with field_cols[1]:
        st.write(f"**Type of Attack:** {result.get('type_of_attack', 'Unknown')}")
    with field_cols[2]:
        st.write(f"**Predicted Stage:** {result['predicted_stage'].replace('_', ' ').title()}")

    # Telemetry chart
    telemetry = pd.DataFrame([values], columns=columns)
    st.subheader("Current-window telemetry")
    st.bar_chart(telemetry.T.rename(columns={0: "value"}))
    
    # Threat forecast chart
    timeline = pd.DataFrame(result["forecast_timeline"])
    timeline["probability_percent"] = timeline["probability"] * 100
    st.subheader("Threat forecast")
    st.line_chart(timeline.set_index("offset_seconds")["probability_percent"])
    
    # Full traffic table (replaces suspicious flows)
    st.subheader("Traffic Flows")
    traffic_df = prepare_traffic_table(result)
    render_traffic_table(traffic_df)


with st.sidebar:
    run_name = st.text_input(
        "Model run", os.environ.get("ATTACK_FORECASTER_DEFAULT_RUN", "demo_bundled")
    )
    steps = st.number_input("Forecast steps", min_value=1, max_value=20, value=5)
    st.header("Live capture")
    available = interfaces()
    interface = st.selectbox("Interface", available or ["eth0"])
    seconds = st.slider("Capture duration (seconds)", 5, 120, 15)
    capture_button = st.button("Capture and analyze", type="primary")
    st.header("Offline input")
    uploaded = st.file_uploader("Upload PCAP or flow CSV", type=["pcap", "pcapng", "cap", "csv"])
    upload_button = st.button("Analyze upload")

path = None
if capture_button:
    try:
        with st.spinner("Capturing local traffic..."):
            path = capture_with_tshark(interface, seconds)
    except RuntimeError as exc:
        st.error(str(exc))
if upload_button and uploaded is not None:
    suffix = os.path.splitext(uploaded.name)[1].lower() or ".pcap"
    handle = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    handle.write(uploaded.getbuffer())
    handle.close()
    path = handle.name

if path:
    try:
        with st.spinner("Extracting features and classifying traffic..."):
            result = run_forecast(path, run_name=run_name, steps=int(steps))
        render_result(path, result)
    except (ForecasterNotTrainedError, PacketParseError, ValueError) as exc:
        st.error(str(exc))
else:
    st.info("Train a model, then capture a bounded live snapshot or upload a capture.")
