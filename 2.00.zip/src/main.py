"""
main.py
=======
The primary CLI entry point: runs the full pipeline on a PCAP or CSV and
renders the plain-text terminal dashboard. Fully offline; no network
access is performed at any point in this script.

Usage:
    python3 main.py --pcap capture.pcap
    python3 main.py --csv traffic.csv
    python3 main.py --pcap capture.pcap --window 10 --steps 5 --run-name default

    # Multi-input / batch mode (many files and/or directories at once, e.g.
    # when this runs on a server against several sensors' captures):
    python3 main.py --input captures/ more.pcap another.csv --run-name default
    python3 main.py --input a.csv b.csv --combine --run-name default
"""

from __future__ import annotations
import argparse
import logging
import os
import sys
import time
import tracemalloc
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from forecast import (
    run_forecast, run_forecast_records, run_forecast_many,
    add_input_arguments, gather_cli_paths, ForecasterNotTrainedError,
)
from feature_extraction import PacketParseError
from live_capture import LiveCapture

logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


BANNER_WIDTH = 80


def memory_status() -> str:
    """Return lightweight process memory telemetry without a hard dependency."""
    current, peak = tracemalloc.get_traced_memory()
    rss = 0
    try:
        import resource
        rss = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if sys.platform != "darwin":
            rss *= 1024
    except (ImportError, AttributeError):
        pass
    tracked_mb = peak / (1024 * 1024)
    rss_mb = rss / (1024 * 1024)
    return f"Python tracked peak: {tracked_mb:.1f} MB | process peak: {rss_mb:.1f} MB"


def display_flow_details(flow: dict) -> str:
    """Format detailed flow information for terminal display."""
    lines = []
    lines.append("")
    lines.append("    " + "-" * (BANNER_WIDTH - 8))
    lines.append(f"    Flow Details: {flow.get('src', 'Unknown')} → {flow.get('dst', 'Unknown')}")
    lines.append("    " + "-" * (BANNER_WIDTH - 8))
    
    details = [
        ("Timestamps", flow.get("timestamps", "N/A")),
        ("Packet Count", f"{flow.get('packet_count', 'N/A')}"),
        ("Byte Count", f"{flow.get('byte_count', 'N/A')}"),
        ("Duration", f"{flow.get('duration', 'N/A')}"),
        ("Payload Size", f"{flow.get('payload_size', 'N/A')}"),
        ("Flags", flow.get("flags", "N/A")),
        ("TTL", f"{flow.get('ttl', 'N/A')}"),
        ("Window Size", f"{flow.get('window_size', 'N/A')}"),
    ]
    
    for key, val in details:
        lines.append(f"    {key:<20}: {val}")
    
    if flow.get("reasoning"):
        lines.append(f"\n    Suspicious Flag Reasoning:")
        lines.append(f"    {flow.get('reasoning')}")
    
    if flow.get("related_stage_data"):
        lines.append(f"\n    Related Stage Data:")
        lines.append(f"    {flow.get('related_stage_data')}")
    
    lines.append("    " + "-" * (BANNER_WIDTH - 8))
    return "\n".join(lines)


def render_dashboard(result: dict) -> str:
    lines = []
    bar = "=" * BANNER_WIDTH
    lines.append(bar)
    lines.append("AI NETWORK ATTACK FORECASTER".center(BANNER_WIDTH))
    lines.append(bar)
    lines.append(f"Input: {result['input']}")
    lines.append(f"Window: {result['window_seconds']} sec | Forecast: {result['forecast_steps']} steps")
    lines.append(f"Windows observed: {result['total_windows_observed']}")
    lines.append(f"Memory: {memory_status()}")
    lines.append("")

    # Updated field names and layout
    prob_pct = result["current_threat_probability"] * 100
    lines.append(f"ATTACK POTENTIAL   : {prob_pct:.0f}%")
    lines.append(f"RISK LEVEL         : {result['risk_level']}")
    lines.append(f"PREDICTED STAGE    : {result['predicted_stage'].replace('_', ' ').title()}")
    lines.append(f"CONFIDENCE         : {result['confidence'] * 100:.0f}%")
    lines.append(f"TYPE OF ATTACK     : {result.get('type_of_attack', 'Unknown')}")
    lines.append("")

    lines.append("FORECAST")
    for step in result["forecast_timeline"]:
        lines.append(f"+{step['offset_seconds']} sec : {step['probability'] * 100:.0f}%")
    lines.append("")

    lines.append("ATTACK PROGRESSION")
    lines.append(" → ".join(s.replace("_", " ").title() for s in result["attack_progression"]))
    lines.append("")

    lines.append("TOP FEATURES")
    for i, feat in enumerate(result["top_features"], 1):
        val = feat["contribution"]
        sign = "+" if val >= 0 else "-"
        lines.append(
            f"{i}. {feat['feature']:<28} value={feat.get('current_value', 0):>10.3f} "
            f"impact={sign}{abs(val):.6f}  ({feat['direction']})"
        )
    lines.append("")

    # Traffic Flows Table (all flows, with suspicious indication)
    lines.append("TRAFFIC FLOWS")
    flows = result.get("all_flows", [])
    suspicious_flows_set = {(f.get("src"), f.get("dst")) for f in result.get("suspicious_flows", [])}
    
    if flows:
        # Header
        lines.append(f"{'Source':<18}{'Destination':<18}{'Protocol':<10}{'Port(s)':<15}{'Attack Stage':<20}{'Suspicious':<12}")
        lines.append("-" * BANNER_WIDTH)
        
        # Sort: suspicious first, then non-suspicious
        sorted_flows = sorted(
            flows,
            key=lambda f: (
                not (f.get("src"), f.get("dst")) in suspicious_flows_set,
                -(f.get("critical_level", 0))
            )
        )
        
        for idx, flow in enumerate(sorted_flows):
            src = flow.get("src", "Unknown")
            dst = flow.get("dst", "Unknown")
            proto = flow.get("protocol", "Unknown")
            ports = str(flow.get("ports", "N/A"))
            stage = flow.get("stage", "N/A")
            is_suspicious = (src, dst) in suspicious_flows_set
            suspicious_flag = "[!]" if is_suspicious else ""
            
            lines.append(
                f"{src:<18}{dst:<18}{proto:<10}{ports:<15}{stage:<20}{suspicious_flag:<12}"
            )
            
            # Add clickable indicator
            if is_suspicious or flow.get("packet_count"):
                lines.append(f"  └─ [Click {idx}] for details")
    else:
        lines.append("(No flows detected or input is flow-CSV based)")
    
    lines.append("")
    lines.append(bar)

    unavailable = [k for k, v in result.get("feature_availability", {}).items() if not v]
    if unavailable:
        lines.append(f"Note: features unavailable for this input source: {', '.join(unavailable)}")
        lines.append(bar)

    return "\n".join(lines)


def render_batch(batch: dict) -> str:
    """Render results for a multi-input (batch or combined) run."""
    lines = []
    bar = "=" * BANNER_WIDTH
    summary = batch["summary"]
    lines.append(bar)
    lines.append("AI NETWORK ATTACK FORECASTER — BATCH".center(BANNER_WIDTH))
    lines.append(bar)
    lines.append(f"Mode: {batch['mode']} | ok: {summary['ok_count']} | "
                 f"errors: {summary['error_count']} | total: {summary['file_count']}")
    if summary["highest_risk_input"] is not None:
        lines.append(f"HIGHEST RISK   : {summary['highest_risk_level']} "
                     f"({summary['highest_threat_probability'] * 100:.0f}%) — "
                     f"{summary['highest_risk_input']}")
        lines.append(f"MEAN THREAT    : {summary['mean_threat_probability'] * 100:.0f}%")
    lines.append(bar)

    for err in batch.get("errors") or []:
        lines.append(f"[SKIPPED] {err['input']}: {err['error']}")
    if batch.get("errors"):
        lines.append(bar)

    for result in batch.get("results") or []:
        lines.append(render_dashboard(result))
        lines.append("")

    return "\n".join(lines)


def run_input(input_path: str, run_name: str, steps: int | None = None) -> dict | None:
    """Analyze one user-selected file and return result for interactive viewing."""
    started = time.perf_counter()
    try:
        result = run_forecast(input_path, run_name=run_name, steps=steps)
    except ForecasterNotTrainedError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        return None
    except PacketParseError as e:
        print(f"\n[ERROR] Could not parse input: {e}\n", file=sys.stderr)
        return None
    except ValueError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        return None
    
    analysis_time = time.perf_counter() - started
    result['analysis_time'] = analysis_time
    return result


def interactive_terminal(result: dict) -> None:
    """Interactive terminal view of a result with flow expansion."""
    flows = result.get("all_flows", [])
    expanded_idx = None
    
    while True:
        # Display dashboard
        print("\033[2J\033[H" if sys.platform != "win32" else "")  # Clear screen
        print(render_dashboard(result))
        
        if expanded_idx is not None and 0 <= expanded_idx < len(flows):
            print(display_flow_details(flows[expanded_idx]))
        
        print(f"\nAnalysis time: {result.get('analysis_time', 0):.2f} seconds")
        print("\n[Instructions]")
        print("  • [0-9] — Click flow number to view details")
        print("  • [F]   — Load another file")
        print("  • [E]   — Exit")
        
        try:
            choice = input("\n> ").strip().lower()
            
            if choice in {"e", "exit", "q", "quit"}:
                print("Exiting.")
                return
            
            if choice in {"f", "file"}:
                raw_path = input("File path (.csv, .pcap, .pcapng): ").strip().strip('"')
                path = Path(raw_path).expanduser()
                if path.is_file() and path.suffix.lower() in {".csv", ".tsv", ".pcap", ".pcapng", ".cap"}:
                    new_result = run_input(str(path), result.get('run_name', 'demo_bundled'), 
                                          result.get('forecast_steps'))
                    if new_result:
                        result = new_result
                        expanded_idx = None
                else:
                    print("File not found or unsupported file type.")
            
            # Try to parse as flow index
            try:
                idx = int(choice)
                if 0 <= idx < len(flows):
                    expanded_idx = idx if expanded_idx != idx else None
                else:
                    print(f"Flow number must be 0-{len(flows)-1}")
            except ValueError:
                if choice:  # Only show error for non-empty invalid input
                    print("Invalid input. Try [0-9], [F], or [E].")
        
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            return


def interactive_mode(run_name: str, steps: int | None = None,
                     refresh_seconds: float = 2.0, interface: str | None = None) -> None:
    """Continuous live forecasting; F analyzes a file and E exits."""
    tracemalloc.start()
    print("LIVE FORECASTING ACTIVE")
    print("  [F] — Analyze a file")
    print("  [E] — Exit")
    print()
    
    capture = LiveCapture(interface=interface)
    try:
        capture.start()
        print(f"Capturing on {capture.interface}; refresh: {refresh_seconds:g} seconds")
    except RuntimeError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return
    
    while True:
        try:
            capture.read_for(refresh_seconds)
            
            if sys.stdin.isatty():
                ready, _, _ = __import__("select").select([sys.stdin], [], [], 0)
                if ready:
                    choice = input("\n[F] File  [E] Exit\n> ").strip().lower()
                    if choice in {"e", "exit", "q", "quit"}:
                        print("Exiting.")
                        capture.close()
                        return
                    if choice in {"f", "file"}:
                        raw_path = input("File path (.csv, .pcap, .pcapng): ").strip().strip('"')
                        path = Path(raw_path).expanduser()
                        if path.is_file() and path.suffix.lower() in {".csv", ".tsv", ".pcap", ".pcapng", ".cap"}:
                            result = run_input(str(path), run_name, steps)
                            if result:
                                print(render_dashboard(result))
                                interactive_terminal(result)
                        else:
                            print("File not found or unsupported file type.")
            
            records = capture.snapshot()
            if records:
                try:
                    result = run_forecast_records(
                        records, f"live://{capture.interface}",
                        run_name=run_name, steps=steps,
                    )
                    print("\033[2J\033[H" + render_dashboard(result))
                    print(f"\nLIVE MODE: [F] file  [E] exit | Packets: {len(records)}")
                except (ValueError, PacketParseError, ForecasterNotTrainedError) as exc:
                    print(f"\rWaiting for forecast: {exc}", end="", flush=True)
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            capture.close()
            return
        except RuntimeError as exc:
            print(f"\n[ERROR] Live capture stopped: {exc}", file=sys.stderr)
            capture.close()
            return


def main():
    tracemalloc.start()
    parser = argparse.ArgumentParser(
        description="AI Network Attack Forecaster — offline early-warning system for Kali Linux."
    )
    add_input_arguments(parser)
    parser.add_argument("--steps", type=int, default=None, help="Override forecast horizon (K steps).")
    parser.add_argument("--run-name", default="demo_bundled",
                        help="Trained model artifacts to use (default: demo_bundled).")
    parser.add_argument("--json", action="store_true", help="Print raw JSON instead of dashboard.")
    parser.add_argument("--interactive", action="store_true",
                        help="Run continuous live forecasting: F analyzes a file, E exits.")
    parser.add_argument("--interface", help="Interface for live mode; default is first non-loopback.")
    parser.add_argument("--refresh-seconds", type=float, default=2.0,
                        help="Live refresh interval in seconds (default: 2).")
    args = parser.parse_args()
    paths = gather_cli_paths(args)

    if args.interactive or not paths:
        interactive_mode(args.run_name, args.steps, args.refresh_seconds, args.interface)
        return

    try:
        batch = run_forecast_many(paths, run_name=args.run_name, steps=args.steps,
                                  combine=args.combine)
    except ForecasterNotTrainedError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        sys.exit(1)
    except PacketParseError as e:
        print(f"\n[ERROR] Could not parse input: {e}\n", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        sys.exit(1)

    # A single successful input keeps the original single-file dashboard
    # output; multiple inputs (or --combine) render the batch view instead.
    single = (len(batch["results"]) == 1 and not batch["errors"]
             and batch["mode"] != "combined")
    payload = batch["results"][0] if single else batch

    if args.json:
        import json
        print(json.dumps(payload, indent=2))
    elif single:
        result = payload
        result['run_name'] = args.run_name
        result['forecast_steps'] = args.steps or result.get('forecast_steps', 5)
        print(render_dashboard(result))
        print(f"Analysis time: {time.perf_counter() - time.perf_counter():.2f} seconds")
        # Enter interactive mode for single file
        interactive_terminal(result)
    else:
        print(render_batch(payload))

    if not batch["results"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
