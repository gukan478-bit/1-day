"""
test_feature_extraction.py
===========================
Tests the CSV flow-extraction path (no external tshark/scapy binary
needed for this backend, so it runs anywhere) and malformed-input
handling for both CSV and PCAP paths.
"""

import os
import sys
import tempfile
import textwrap

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
from feature_extraction import (
    extract_from_flow_csv, extract_from_pcap, extract_many, collect_input_paths,
    PacketParseError,
)


def _write_csv(tmp_path, content: str) -> str:
    path = os.path.join(tmp_path, "flows.csv")
    with open(path, "w") as f:
        f.write(textwrap.dedent(content).strip() + "\n")
    return path


def test_extract_from_flow_csv_basic(tmp_path):
    csv_content = """\
        Src IP,Dst IP,Src Port,Dst Port,Protocol,Flow Duration,Tot Fwd Pkts,Tot Bwd Pkts,SYN Flag Cnt,Label
        10.0.0.1,10.0.0.2,1234,80,TCP,1000000,10,8,1,BENIGN
        10.0.0.3,10.0.0.4,5555,22,TCP,500000,50,0,50,FTP-Patator
    """
    path = _write_csv(tmp_path, csv_content)
    records = extract_from_flow_csv(path)
    assert len(records) == 2
    assert records[0]["label"] == "BENIGN"
    assert records[1]["label"] == "FTP-Patator"
    assert records[1]["syn_flag_cnt"] == 50.0
    assert records[0]["_is_flow_record"] is True


def test_extract_from_flow_csv_missing_file_raises():
    with pytest.raises(PacketParseError):
        extract_from_flow_csv("/nonexistent/path/flows.csv")


def test_extract_from_flow_csv_unrecognized_schema_raises(tmp_path):
    csv_content = """\
        RandomColumnA,RandomColumnB
        1,2
    """
    path = _write_csv(tmp_path, csv_content)
    with pytest.raises(PacketParseError):
        extract_from_flow_csv(path)


def test_extract_from_flow_csv_malformed_rows_are_skipped_not_fatal(tmp_path):
    csv_content = """\
        Src IP,Dst IP,Src Port,Dst Port,Protocol,Label
        10.0.0.1,10.0.0.2,80,443,TCP,BENIGN
        this,row,is,garbage
        10.0.0.5,10.0.0.6,22,22,TCP,BENIGN
    """
    path = _write_csv(tmp_path, csv_content)
    records = extract_from_flow_csv(path)
    # malformed row should be skipped gracefully, not crash extraction
    assert len(records) >= 2


def test_extract_from_pcap_missing_file_raises():
    with pytest.raises(PacketParseError):
        extract_from_pcap("/nonexistent/path/capture.pcap")


def test_extract_from_pcap_empty_file_raises_or_returns_empty(tmp_path):
    bad_path = os.path.join(tmp_path, "not_a_real.pcap")
    with open(bad_path, "wb") as f:
        f.write(b"NOT A VALID PCAP FILE HEADER")
    with pytest.raises(PacketParseError):
        extract_from_pcap(bad_path, use_pyshark_fallback=False)


def test_collect_input_paths_files_and_directory(tmp_path):
    csv_a = tmp_path / "a.csv"
    csv_b = tmp_path / "nested" / "b.csv"
    csv_b.parent.mkdir()
    csv_a.write_text("Src IP,Dst IP,Src Port,Dst Port,Protocol,Label\n10.0.0.1,10.0.0.2,1,2,TCP,BENIGN\n")
    csv_b.write_text("Src IP,Dst IP,Src Port,Dst Port,Protocol,Label\n10.0.0.3,10.0.0.4,3,4,TCP,BENIGN\n")
    (tmp_path / "ignore.txt").write_text("nope")

    paths = collect_input_paths([str(csv_a), str(tmp_path / "nested")])
    assert len(paths) == 2
    assert any(p.endswith("a.csv") for p in paths)
    assert any(p.endswith("b.csv") for p in paths)

    all_from_dir = collect_input_paths([str(tmp_path)])
    assert len(all_from_dir) == 2


def test_collect_input_paths_missing_raises():
    with pytest.raises(PacketParseError):
        collect_input_paths(["/this/path/does/not/exist-xyz"])


def test_extract_many_concatenates_csv_files(tmp_path):
    for name, src in (("one.csv", "10.0.0.1"), ("two.csv", "10.0.0.9")):
        (tmp_path / name).write_text(
            "Src IP,Dst IP,Src Port,Dst Port,Protocol,Label\n"
            f"{src},10.0.0.2,1,2,TCP,BENIGN\n"
        )
    records = extract_many([str(tmp_path / "one.csv"), str(tmp_path / "two.csv")])
    assert len(records) == 2
    ips = {r["src_ip"] for r in records}
    assert ips == {"10.0.0.1", "10.0.0.9"}
